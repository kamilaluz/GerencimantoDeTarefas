﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GerenciadorDeTarefas.Enum
{
    public enum status : ushort
    {
        Pendente,
        Fazendo,
        Concluída,
        Cancelada
    }
}
